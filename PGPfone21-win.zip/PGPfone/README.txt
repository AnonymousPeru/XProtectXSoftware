
 Readme file for PGPfone 2.1
 ---------------------------

This is PGPfone 2.1, taken from the PGP 6.5.1 source code distribution,
which was legally exported from the USA as a printed book and later
scanned and OCRed to recreate the source in electronic form.

This archive contains:

README.txt      - This file.

README-src.txt  - Important information about the status of PGPfone 2.1.

src/            - The source code for PGPfone 2.1 for win32.

win32/          - Precompiled client for win32. Just copy the files to
                  its own directory, start PGPfone.exe and off you go.

manual-10b7.pdf - The manual for PGPfone 1.0 in PDF format. This manual
                  is a little out of date, but most of it also applies
                  to version 2.1.

For more information about PGPfone and PGP, please visit:

  http://www.pgpi.org/products/nai/pgpfone/



Stale Schumacher Ytteborg
stale@hypnotech.com
10 November 1999
