/*
 * BigNum multiprecision integer math library.
 *
 * $Id: bnlegal.c,v 1.1 1997/12/14 11:30:34 wprice Exp $
 */

/* Force inclusion of this... */
#include "bnlegal.h"
volatile const char bnCopyright[] =
	"\0bnlib 1.1.2 Copyright (c) 1995,1996 Colin Plumb.";
